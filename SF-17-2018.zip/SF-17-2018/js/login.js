var dataURL = "https://wd-projekat-b26a5-default-rtdb.firebaseio.com/korisnici";

var loginForm = document.getElementById('loginForm');

loginForm.addEventListener('submit', function (e) {
    e.preventDefault();

    var username = document.getElementById('txtUsername').value.trim();
    var password = document.getElementById('txtPassword').value.trim();

    if (username == '' || password == '') {
        alert('Morate uneti sve podatke za prijavu.');
    } else {

        var request = new XMLHttpRequest();

        request.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    var korisnici = JSON.parse(request.responseText);

                    var ime = '';
                    for (var i = 0; i < korisnici.length; i++) {
                        var korisnik = korisnici[i];
                        if (korisnik.username == username && korisnik.password == password) {
                            ime = korisnik.ime;
                            break;
                        }
                    }
                    if (ime == '') {
                        alert('Neispravni login podaci.');
                    } else {
                        window.location.replace("index.html?korisnik=" + ime);
                        
                    }
                } else {
                    alert('GRESKA: ' + this.status)
                }
            }
        };
        var url = loginForm.getAttribute('action');
        request.open('GET', url);
        request.send();
    }
});