var trenutnaKnjiga;
var knjigaURL = "https://wd-projekat-b26a5-default-rtdb.firebaseio.com/knjige";
var overlay = document.getElementById('overlay')

var request = new XMLHttpRequest();

request.onreadystatechange = function () {
    if (this.readyState == 4) {
        if (this.status == 200) {
            var knjige = JSON.parse(request.responseText);

            for (var i = 0; i < knjige.length; i++) {
                var knjiga = knjige[i];

                var newDiv = document.createElement('div');
                newDiv.classList.add('previewDiv');
                newDiv.setAttribute('data-autor', knjiga.autor);
                newDiv.setAttribute('data-brojStranica', knjiga.brojStranica);
                newDiv.setAttribute('data-cena', knjiga.cena);
                newDiv.setAttribute('data-godinaIzdavanja', knjiga.godinaIzdavanja);
                newDiv.setAttribute('data-isbn', knjiga.isbn);
                newDiv.setAttribute('data-izdavackaKuca', knjiga, izdavackaKuca);
                newDiv.setAttribute('data-jezik', knjiga.jezik);
                newDiv.setAttribute('data-naziv', knjiga.naziv);
                newDiv.setAttribute('data-ocena', knjiga.ocena);
                newDiv.setAttribute('data-opis', knjiga.opis);
                newDiv.setAttribute('data-pismo', knjiga.pismo);
                newDiv.setAttribute('data-tipPoveza', knjiga.tipPoveza);

                newDiv.addEventListener('click', function (e) {
                    e.stopPropagation();
                    trenutnaKnjiga = this;

                    var autorEl = document.getElementById('autorPlaceholder');
                    autorEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-autor'));

                    var brojStranicaEl = document.getElementById('brojStraicaPlaceholder');
                    brojStranicaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-brojStranica'));

                    var cenaEl = document.getElementById('cenaPlaceholder');
                    cenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-cena'));

                    var godiaIzdavajaEl = document.getElementById('godiaIzdavajaPlaceholder');
                    godiaIzdavajaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-godiaIzdavaja'));

                    var isbnEl = document.getElementById('isbnPlaceholder');
                    isbnEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-isbn'));

                    var izdavackaKucaEl = document.getElementById('izdavackaKucaPlaceholder');
                    izdavackaKucaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-izdavackaKuca'));

                    var jezikEl = document.getElementById('jezikPlaceholder');
                    jezikEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-jezik'));

                    var nazivEl = document.getElementById('nazivPlaceholder');
                    nazivEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-naziv'));

                    var ocenaEl = document.getElementById('ocenaPlaceholder');
                    ocenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-ocena'));

                    var opisEl = document.getElementById('opisPlaceholder');
                    opisEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-opis'));

                    var pismoEl = document.getElementById('pismoPlaceholder');
                    pismoEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-pismo'));

                    var tipPovezaEl = document.getElementById('tipPovezaPlaceholder');
                    tipPovezaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-tipPoveza'));

                    overlay.style.display = 'block';
                });
                var contentDiv = document.getElementById('content');
                contentDiv.appendChild(newDiv);
            }
        } else {
            alert('Greska prilikom ucitavanja knjige.')
        }
    }
}

request.open('GET', knjigaURL);
request.send();

var leftArrow = document.getElementById('leftArrow');
leftArrow.addEventListener('click', function (e) {
    var previous = trenutnaKnjiga.previousElementSibling;
    if (previous !== null) {
        trenutnaKnjiga = previous;

        var autorEl = document.getElementById('autorPlaceholder');
        autorEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-autor'))

        var brojStranicaEl = document.getElementById('brojStraicaPlaceholder');
        brojStranicaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-brojStranica'));

        var cenaEl = document.getElementById('cenaPlaceholder');
        cenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-cena'));

        var godiaIzdavajaEl = document.getElementById('godiaIzdavajaPlaceholder');
        godiaIzdavajaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-godiaIzdavaja'));

        var isbnEl = document.getElementById('isbnPlaceholder');
        isbnEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-isbn'));

        var izdavackaKucaEl = document.getElementById('izdavackaKucaPlaceholder');
        izdavackaKucaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-izdavackaKuca'));

        var jezikEl = document.getElementById('jezikPlaceholder');
        jezikEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-jezik'));

        var nazivEl = document.getElementById('nazivPlaceholder');
        nazivEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-naziv'));

        var ocenaEl = document.getElementById('ocenaPlaceholder');
        ocenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-ocena'));

        var opisEl = document.getElementById('opisPlaceholder');
        opisEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-opis'));

        var pismoEl = document.getElementById('pismoPlaceholder');
        pismoEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-pismo'));

        var tipPovezaEl = document.getElementById('tipPovezaPlaceholder');
        tipPovezaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-tipPoveza'));
    }
});

var rightArrow = document.getElementById('rightArrow');
rightArrow.addEventListener('click', function (e) {
    var next = trenutnaKnjiga.nextElementSibling;
    if (next !== null) {
        trenutnaKnjiga = next;

        var autorEl = document.getElementById('autorPlaceholder');
        autorEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-autor'))

        var brojStranicaEl = document.getElementById('brojStraicaPlaceholder');
        brojStranicaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-brojStranica'));

        var cenaEl = document.getElementById('cenaPlaceholder');
        cenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-cena'));

        var godiaIzdavajaEl = document.getElementById('godiaIzdavajaPlaceholder');
        godiaIzdavajaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-godiaIzdavaja'));

        var isbnEl = document.getElementById('isbnPlaceholder');
        isbnEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-isbn'));

        var izdavackaKucaEl = document.getElementById('izdavackaKucaPlaceholder');
        izdavackaKucaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-izdavackaKuca'));

        var jezikEl = document.getElementById('jezikPlaceholder');
        jezikEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-jezik'));

        var nazivEl = document.getElementById('nazivPlaceholder');
        nazivEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-naziv'));

        var ocenaEl = document.getElementById('ocenaPlaceholder');
        ocenaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-ocena'));

        var opisEl = document.getElementById('opisPlaceholder');
        opisEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-opis'));

        var pismoEl = document.getElementById('pismoPlaceholder');
        pismoEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-pismo'));

        var tipPovezaEl = document.getElementById('tipPovezaPlaceholder');
        tipPovezaEl.setAttribute('src', trenutnaKnjiga.getAttribute('data-tipPoveza'));
    }
});